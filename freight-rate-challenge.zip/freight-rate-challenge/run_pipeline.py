#!/usr/bin/env python
# coding: utf-8

# # Freight Rate Prediction – full solution
# 
# **Goal:** predict `posted_rate` for the 12,000 loads in `validation.csv` (Nov–Dec 2025) and for 31 fixed December
# chart rows, using only the labeled Jan–Oct 2025 data in `train_test.csv`.
# 
# **Pipeline in one picture**
# 
# 1. Load data → 2. Audit data quality → 3. Explore → 4. Handle label outliers → 5. Choose a *time-based* validation
# scheme → 6. Compare models with cross-validation → 7. Tune lightly → 8. Fit final model on all labeled data →
# 9. Predict validation + December → 10. Sanity-check and run `score.py`.
# 
# Every code line below has a comment saying what it does; every step starts with a short note on **why**.

# ## 0. Setup
# **Why:** import the libraries once, fix the random seed so results are reproducible, and point at the data folder.

# In[1]:


import sys, subprocess, warnings                 # sys/subprocess: run score.py at the end; warnings: silence noise
from pathlib import Path                         # clean file-path handling
import numpy as np                               # numeric arrays and maths
import pandas as pd                              # tables (DataFrames)
import matplotlib.pyplot as plt                  # plotting
import lightgbm as lgb                           # gradient-boosted trees (our model)
from IPython.display import Image, display       # show saved PNGs inside the notebook

from features import FeatureBuilder, drop_label_outliers   # our own cleaning + feature code (features.py)

warnings.filterwarnings("ignore")                # hide harmless library warnings
SEED = 42                                        # one seed used everywhere -> reproducible
DATA = Path("data")                              # folder holding the CSV files
FIG = Path("figures"); FIG.mkdir(exist_ok=True)  # folder for charts (created if missing)
RES = Path("results"); RES.mkdir(exist_ok=True)  # folder for result tables
plt.rcParams.update({"figure.dpi": 110, "axes.spines.top": False, "axes.spines.right": False})  # tidy plot style


# ## 1. Load the data
# **Why:** `parse_dates` turns the `date` text into real dates so we can split and group by time.

# In[2]:


train = pd.read_csv(DATA / "train_test.csv", parse_dates=["date"])        # 48,000 labeled loads (has posted_rate)
val = pd.read_csv(DATA / "validation.csv", parse_dates=["date"])          # 12,000 loads to predict (no posted_rate)
dec = pd.read_csv(DATA / "december_chart_inputs.csv")                     # 31 fixed December chart rows
template = pd.read_csv(DATA / "validation_predictions_template.csv")      # required load_id order for the answer file

print("train", train.shape, "| validation", val.shape, "| december", dec.shape)   # sizes of each table
print(list(train.columns))                                                # column names
train.head(3)                                                             # first 3 rows


# ## 2. Data-quality audit
# **Why:** before modelling, measure exactly what is wrong in *both* train and validation. Anything wrong in validation
# must be **fixed**, not dropped, because we owe a prediction for all 12,000 loads.

# In[3]:


def audit(df, name):                                                      # build one column of facts about a dataset
    return pd.Series({
        "rows": len(df),                                                  # number of rows
        "first_date": df["date"].min().date(),                            # earliest date
        "last_date": df["date"].max().date(),                             # latest date
        "missing_weight": int(df["weight"].isna().sum()),                 # empty weight cells
        "negative_weight": int((df["weight"] < 0).sum()),                 # impossible negative weights
        "missing_market_index": int(df["market_index"].isna().sum()),     # empty market_index cells
        "missing_quote_signal": int(df["quote_signal"].isna().sum()),     # empty quote_signal cells
        "duplicate_load_id": int(df["load_id"].duplicated().sum()),       # repeated ids
        "duplicate_rows_ignoring_id": int(df.drop(columns="load_id").duplicated().sum()),  # repeated loads
        "pickup_equals_delivery": int((df["pickup"] == df["delivery"]).sum()),             # nonsensical routes
    }, name=name)

report = pd.concat([audit(train, "train"), audit(val, "validation")], axis=1)   # side-by-side table
report.to_csv(RES / "data_quality_audit.csv")                                   # save for the report
display(report)

seen = set(train["pickup"]) | set(train["delivery"])                            # every city that appears in train
new_cities = (set(val["pickup"]) | set(val["delivery"])) - seen                 # cities only validation has
print("Cities in validation but never in train:", sorted(new_cities))
lane_key = lambda d: d["pickup"] + ">" + d["delivery"]                          # a lane = origin>destination
unseen_lane = ~lane_key(val).isin(set(lane_key(train)))                         # validation loads on lanes train never saw
print(f"Validation rows on lanes never seen in train: {unseen_lane.mean():.1%}  <- feature fallbacks must be safe")
print("Equipment values:", train["equipment"].unique(), "| validation:", val["equipment"].unique())


# ## 3. Exploration
# **Why:** find what drives the rate, so features and the validation plan match reality.
# We look at (a) rate per mile over time next to `market_index`, (b) rate vs distance by equipment.

# In[4]:


eda = train.assign(rpm=train["posted_rate"] / train["distance"])          # add rate-per-mile (a copy; train untouched)
monthly = eda.groupby(eda["date"].dt.to_period("M")).agg(                 # one row per month
    rpm=("rpm", "median"), market_index=("market_index", "mean"), loads=("rpm", "size"))
val_mi = val.groupby(val["date"].dt.to_period("M"))["market_index"].mean()   # validation market_index by month
print(monthly.round(3))
print("validation market_index by month:", val_mi.round(3).to_dict())
print("\nCorrelation of rate with distance:", round(train["posted_rate"].corr(train["distance"]), 3))
print("Median rate/mile by equipment:\n", eda.groupby("equipment")["rpm"].median().round(3))

fig, ax = plt.subplots(1, 2, figsize=(14, 4.3))                           # two charts side by side
m = monthly.index.to_timestamp()                                          # month start dates for the x-axis
ax[0].plot(m, monthly["rpm"], marker="o", color="#064A56")                # median rate per mile by month
ax[0].set_ylabel("median rate per mile ($)", color="#064A56")
tw = ax[0].twinx()                                                        # second y-axis for market_index
tw.plot(m, monthly["market_index"], marker="s", color="#D9822B")          # train market_index by month
vm = val_mi.index.to_timestamp()
tw.plot(vm, val_mi.values, marker="s", ls="--", color="#D9822B")          # validation market_index (dashed)
tw.set_ylabel("mean market_index", color="#D9822B")
ax[0].set_title("Rate per mile vs market_index (dashed = validation months)")
samp = eda.sample(4000, random_state=SEED)                                # sample so the scatter stays readable
for eq, g in samp.groupby("equipment"):                                   # one colour per equipment type
    ax[1].scatter(g["distance"], g["posted_rate"], s=4, alpha=.45, label=eq)
ax[1].set_xlabel("distance (miles)"); ax[1].set_ylabel("posted_rate ($)")
ax[1].set_title("Rate is almost linear in distance, with an equipment effect"); ax[1].legend(markerscale=4)
plt.tight_layout(); plt.savefig(FIG / "eda_overview.png"); plt.show()    # save for the report, then display


# ## 4. Label outliers (train only)
# **Why:** a handful of loads have rates that are impossible for their distance/equipment/month. They are *label noise*,
# and they would pull the model toward wrong values.
# We compare each load's rate-per-mile with the median for the same equipment and month. If the data were healthy we
# would see one bell; instead there are two extra clumps far away from 1.0.

# In[5]:


ratio = (eda["rpm"] / eda.groupby(["equipment", eda["date"].dt.to_period("M")])["rpm"].transform("median"))  # 1.0 = typical
bands = pd.cut(ratio, [0, .5, .7, 1.5, 2, 100], labels=["<0.5x", "0.5-0.7x", "0.7-1.5x (normal)", "1.5-2x", ">2x"])
print(bands.value_counts().sort_index())                                  # how many rows fall in each band

fig, ax = plt.subplots(figsize=(8, 3.6))
ax.hist(np.log10(ratio), bins=150, color="#064A56")                       # histogram on a log scale
for t in (0.5, 2.0):                                                      # our keep-window edges
    ax.axvline(np.log10(t), color="crimson", ls="--")
ax.set_xlabel("log10( load rate-per-mile / typical rate-per-mile )"); ax.set_ylabel("loads")
ax.set_title("Two noise clumps outside the 0.5x-2x window (red lines)")
plt.tight_layout(); plt.savefig(FIG / "outliers.png"); plt.show()

train_clean = drop_label_outliers(train)                                  # drop outliers from TRAIN only


# ## 5. Validation strategy (the most important decision)
# **Why time-based, not random?** The final task is *forecasting*: train on Jan–Oct, predict Nov–Dec. A random split puts
# loads from the same days in both train and test, so the model can lean on date-specific information it will never have
# in real use and the score looks better than it should. So we mimic the real task with an **expanding-window** split:
# 
# | Fold | Train on | Evaluate on |
# |---|---|---|
# | 1 | Jan – Jun | Jul – Aug |
# | 2 | Jan – Jul | Aug – Sep |
# | 3 | Jan – Aug | Sep – Oct |
# 
# Rules that keep it honest: outlier-dropping, imputation values, the baseline line and city/lane effects are all
# **fit on the training window only**; the holdout is **never** cleaned of outliers for the *official* score
# (we also print a "clean holdout" number purely as a diagnostic).

# In[6]:


FOLDS = [("2025-07-01", "2025-09-01"), ("2025-08-01", "2025-10-01"), ("2025-09-01", "2025-11-01")]  # (holdout start, holdout end)

fig, ax = plt.subplots(figsize=(9, 2.2))                                  # picture of the split for the report
for i, (s, e) in enumerate(FOLDS):
    s_, e_ = pd.Timestamp(s), pd.Timestamp(e)
    ax.barh(i, (s_ - pd.Timestamp("2025-01-01")).days, left=pd.Timestamp("2025-01-01").toordinal(), color="#064A56")
    ax.barh(i, (e_ - s_).days, left=s_.toordinal(), color="#D9822B")
ax.set_yticks(range(3)); ax.set_yticklabels([f"Fold {i+1}" for i in range(3)])
ax.set_xticks([pd.Timestamp(f"2025-{m:02d}-01").toordinal() for m in range(1, 12)])
ax.set_xticklabels(["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov"])
ax.set_title("Expanding-window validation: teal = train, orange = holdout"); ax.invert_yaxis()
plt.tight_layout(); plt.savefig(FIG / "split_strategy.png"); plt.show()

def believable(h):                                                        # diagnostic mask: rows that are not label outliers
    r = h["posted_rate"] / h["distance"]                                  # rate per mile of holdout rows
    t = r.groupby([h["equipment"], h["date"].dt.to_period("M")]).transform("median")   # their month's typical value
    return ((r / t > .5) & (r / t < 2.0)).to_numpy()

def make_fold(fit, hold, include_market=False):                           # build features for one train/holdout pair
    fit = drop_label_outliers(fit, verbose=False).reset_index(drop=True)  # outliers removed from TRAIN window only
    fb = FeatureBuilder(include_market=include_market, seed=SEED)         # fresh feature builder (learns nothing yet)
    Xf = fb.fit_transform(fit)                                            # learn from the train window, build its features
    Xh = fb.transform(hold)                                               # apply what was learned to the holdout
    return {"fit": fit, "hold": hold.reset_index(drop=True), "Xf": Xf, "Xh": Xh, "ok": believable(hold)}

def time_folds(include_market=False):                                     # build all three time-based folds
    out = []
    for s, e in FOLDS:
        fit = train[train["date"] < s]                                    # everything BEFORE the holdout starts
        hold = train[(train["date"] >= s) & (train["date"] < e)]          # the next two months
        out.append(make_fold(fit, hold, include_market))
    return out

D = time_folds()                                                          # default features (no market_index)
DM = time_folds(include_market=True)                                      # same folds incl. market_index features
print([f"{len(d['fit'])} train / {len(d['hold'])} holdout" for d in D])


# ## 6. Candidate models
# **Why this ladder?** Start with trivial baselines so we know what "good" means, then add complexity only if it earns it.
# 
# 1. **Naive:** median rate-per-mile × distance.
# 2. **Linear baseline:** `log(rate) ~ log(distance)` fitted separately per equipment (already inside `features.py`).
# 3. **Linear + weight:** adds weight (weight turned out to matter once distance is accounted for).
# 4. **LightGBM on the baseline's residual:** the line handles the big, extrapolatable distance effect; trees learn the
#    small leftovers (weight, quote_signal, cities, calendar). *Boosting the residual* matters because trees cannot
#    extrapolate beyond what they saw, but a line can.
# 5. Variants: without `quote_signal`, and with `market_index` features.
# 
# **Metric:** MAE ($) and MAPE (%) — we don't know which one Spotter uses, so we report both. We train with an L1
# (absolute-error) loss on log-rate, which targets the *median* and is robust to leftover noisy labels.

# In[7]:


BASE = dict(objective="l1", n_estimators=300, learning_rate=0.03, num_leaves=5, min_child_samples=60,
            subsample=0.8, subsample_freq=1, colsample_bytree=0.8, verbose=-1)   # LightGBM settings (tuned in section 7)

def metrics(pred, actual, ok):                                            # score predictions in dollars and percent
    err = np.abs(pred - actual); pct = err / actual * 100                 # absolute error, percentage error
    return {"raw_MAE": err.mean(), "raw_MAPE": pct.mean(),                # official-style score (all holdout rows)
            "clean_MAE": err[ok].mean(), "clean_MAPE": pct[ok].mean()}    # diagnostic score (outlier rows excluded)

def predict_lgbm(f, params=None, drop=(), seeds=(SEED,)):                 # train on a fold's train window, predict holdout
    cols = [c for c in f["Xf"].columns if c not in drop]                  # which features to use
    y = np.log(f["fit"]["posted_rate"].to_numpy()) - f["Xf"]["baseline_log_rate"].to_numpy()   # target = what the line missed
    logs = []
    for s in seeds:                                                       # (several seeds are averaged for stability)
        m = lgb.LGBMRegressor(**{**BASE, **(params or {}), "random_state": s}).fit(f["Xf"][cols], y)
        logs.append(m.predict(f["Xh"][cols]))                             # predicted residual on the holdout
    return np.exp(np.mean(logs, axis=0) + f["Xh"]["baseline_log_rate"].to_numpy())   # line + residual, back to dollars

def cv(name, data, kind="lgbm", **kw):                                    # average a model's score over the 3 folds
    rows = []
    for f in data:
        actual = f["hold"]["posted_rate"].to_numpy()
        if kind == "naive":                                               # median rate/mile x distance
            pred = (f["fit"]["posted_rate"] / f["fit"]["distance"]).median() * f["hold"]["distance"].to_numpy()
        elif kind == "linear":                                            # distance x equipment line only
            pred = np.exp(f["Xh"]["baseline_log_rate"].to_numpy())
        elif kind == "linear+weight":                                     # line + a linear weight correction
            A = lambda X: np.column_stack([np.ones(len(X)), X["weight_k"]])
            y = np.log(f["fit"]["posted_rate"].to_numpy()) - f["Xf"]["baseline_log_rate"].to_numpy()
            b, *_ = np.linalg.lstsq(A(f["Xf"]), y, rcond=None)            # fit the weight slope on train window only
            pred = np.exp(A(f["Xh"]) @ b + f["Xh"]["baseline_log_rate"].to_numpy())
        else:                                                             # LightGBM on the residual
            pred = predict_lgbm(f, **kw)
        rows.append(metrics(pred, actual, f["ok"]))
    return pd.Series(pd.DataFrame(rows).mean(), name=name)                # mean over folds

results = pd.concat([
    cv("1 naive: median rate/mile x distance", D, "naive"),
    cv("2 linear: distance x equipment", D, "linear"),
    cv("3 linear + weight", D, "linear+weight"),
    cv("4 LightGBM on residual (FINAL)", D),
    cv("5a  same, without quote_signal", D, drop=("quote_signal",)),
    cv("5b  same, WITH market_index features", DM),
], axis=1).T.round(2)
results.to_csv(RES / "cv_results.csv")                                    # saved for the report
display(results)


# In[8]:


fig, ax = plt.subplots(1, 2, figsize=(13, 3.8))                           # bar chart of the results table
short = ["naive", "linear", "lin+weight", "LGBM (final)", "LGBM no quote", "LGBM +market"]
for a, col, ttl in zip(ax, ["raw_MAPE", "clean_MAPE"], ["Raw holdout MAPE % (lower = better)", "Clean holdout MAPE %"]):
    a.bar(short, results[col], color=["#9DAFB3"] * 3 + ["#064A56", "#9DAFB3", "#D9822B"])
    a.set_title(ttl); a.tick_params(axis="x", rotation=25)
    for i, v in enumerate(results[col]): a.text(i, v, f"{v:.2f}", ha="center", va="bottom", fontsize=8)
plt.tight_layout(); plt.savefig(FIG / "cv_comparison.png"); plt.show()


# ### Why a random split would have fooled us
# **Why:** to *prove* the time-based split matters, score the same two models on a random 80/20 split of all labeled data.
# If the market_index model looks much better there than on the time split, that gap is leakage/over-optimism.

# In[9]:


rng = train.sample(frac=1.0, random_state=SEED)                           # shuffle all rows
cut = int(len(rng) * 0.8)                                                 # 80% train / 20% test
rand_fit, rand_hold = rng.iloc[:cut], rng.iloc[cut:]                      # random split ignoring time
rows = []
for name, inc in [("LGBM without market_index", False), ("LGBM with market_index", True)]:
    f = make_fold(rand_fit, rand_hold, include_market=inc)                # same code path, random split
    p = predict_lgbm(f)
    rows.append({"model": name, "split": "random 80/20", **metrics(p, f["hold"]["posted_rate"].to_numpy(), f["ok"])})
    t = cv(name, DM if inc else D)                                        # same model on the time-based folds
    rows.append({"model": name, "split": "time-based (3 folds)", **t.to_dict()})
leak = pd.DataFrame(rows).round(2)
leak.to_csv(RES / "random_vs_time_split.csv", index=False)
display(leak[["model", "split", "raw_MAPE", "clean_MAPE"]])


# ## 7. Light hyper-parameter tuning
# **Why:** small grid, scored with the same time-based folds. Earlier experiments showed *simpler* is better here (the
# signal is mostly linear), so we only search small trees and a moderate number of rounds.
# We pick by **raw MAE** (the realistic all-rows score), then check the choice is stable in the other metrics.

# In[10]:


grid = []
for leaves in (3, 5, 7):                                                  # tree size: small = simple
    for trees in (200, 300, 600):                                         # number of boosting rounds
        r = cv(f"leaves={leaves}, trees={trees}", D, params=dict(num_leaves=leaves, n_estimators=trees))
        grid.append({"num_leaves": leaves, "n_estimators": trees, **r.to_dict()})
grid = pd.DataFrame(grid).sort_values("raw_MAE").round(2)                 # best (lowest error) first
grid.to_csv(RES / "tuning_grid.csv", index=False)
display(grid)
best = grid.iloc[0]                                                       # winning row
BEST = dict(num_leaves=int(best["num_leaves"]), n_estimators=int(best["n_estimators"]))
print("chosen:", BEST)


# ## 8. Final model (all labeled data)
# **Why:** the validation set is *after* October, so the final model should use as much history as possible: all of
# Jan–Oct, with outliers removed from the training rows only. We average 5 random seeds (the trees use row/column
# sub-sampling) to make predictions less jumpy.

# In[11]:


fb = FeatureBuilder(seed=SEED)                                            # final feature builder
X_train = fb.fit_transform(train_clean)                                   # learn on ALL cleaned train rows, build features
X_val = fb.transform(val)                                                 # validation: transform only (no learning!)
print(X_train.shape, X_val.shape, "| NaNs:", int(X_train.isna().sum().sum()), int(X_val.isna().sum().sum()))

y_resid = np.log(train_clean["posted_rate"].to_numpy()) - X_train["baseline_log_rate"].to_numpy()   # target: residual of the line
models = [lgb.LGBMRegressor(**{**BASE, **BEST, "random_state": s}).fit(X_train, y_resid)            # one model per seed
          for s in range(SEED, SEED + 5)]

def predict_final(X):                                                     # features -> dollars
    resid = np.mean([m.predict(X[X_train.columns]) for m in models], axis=0)   # average the 5 models' residual predictions
    return np.exp(resid + X["baseline_log_rate"].to_numpy())              # add the line back, undo the log

val_pred = predict_final(X_val)                                           # 12,000 predictions
print(pd.Series(val_pred).describe().round(1))


# In[12]:


imp = pd.Series(models[0].booster_.feature_importance("gain"), X_train.columns)   # how much each feature helped
imp = (imp / imp.sum()).sort_values().tail(12)                            # share of total gain, top 12
ax = imp.plot.barh(figsize=(7, 4), color="#064A56"); ax.set_title("Top features (residual model, share of gain)")
plt.tight_layout(); plt.savefig(FIG / "feature_importance.png"); plt.show()


# ## 9. Predictions
# **Why:** the answer file must have exactly `load_id,predicted_rate`, all 12,000 ids, in the template's order, with
# positive numbers. We merge on `load_id` (not on row position) so order mistakes cannot happen.

# In[13]:


pred_df = pd.DataFrame({"load_id": val["load_id"], "predicted_rate": val_pred.round(2)})   # our predictions with their ids
out = template[["load_id"]].merge(pred_df, on="load_id", how="left")      # follow the template's id order
assert len(out) == 12_000 and out["predicted_rate"].notna().all() and (out["predicted_rate"] > 0).all()
assert out["load_id"].is_unique                                           # no duplicate ids
out.to_csv("validation_predictions.csv", index=False)                     # the file to submit
print(out.head(3), "\nsaved", out.shape)

# ---- December chart: same load every day, only the date changes ----
dec_in = dec.drop(columns="predicted_rate")                               # features only (the column is still empty)
X_dec = fb.transform(dec_in, market_context=val)                          # this file has no quote_signal -> use the per-date
                                                                          # average from validation.csv (features, not labels)
dec["predicted_rate"] = predict_final(X_dec).round(2)                     # predict the 31 days
dec.to_csv(DATA / "december_chart_inputs.csv", index=False)               # fill the file in place (as README asks)
display(dec[["date", "predicted_rate"]].T)


# ## 10. Sanity checks (does the output look like freight?)
# **Why:** metrics on Jan–Oct can't tell us if Nov–Dec output is sensible. We check (a) the predicted rate-per-mile is in
# the historical range, (b) the December chart sits near what that lane actually paid, (c) which inputs *shifted* between
# train and validation. (This check caught a real bug: my first fallback for unseen-lane distances gave absurd values
# for some city pairs, so unseen lanes now simply trust the load's own reported distance.)

# In[14]:


vp = val.assign(pred=val_pred, rpm=val_pred / val["distance"])            # validation rows with predicted rate/mile
print("Predicted rate/mile by month (validation):\n", vp.groupby(vp["date"].dt.to_period("M"))["rpm"].median().round(3))
print("Actual median rate/mile Sep & Oct (train):\n", eda[eda["date"] >= "2025-09-01"].groupby(eda["date"].dt.to_period("M"))["rpm"].median().round(3))

lane = train_clean[(train_clean["pickup"] == "Lexington") & (train_clean["delivery"] == "Fort Wayne")   # the chart's lane ...
                   & (train_clean["equipment"] == "Dry Van")]                                              # ... and equipment
lane_m = (lane["posted_rate"] / lane["distance"] * 360).groupby(lane["date"].dt.to_period("M")).median()   # scaled to 360 miles
print("\nHistorical Lexington->Fort Wayne Dry Van, rate scaled to 360 mi:\n", lane_m.round(0).to_dict())
print("December prediction range: $%.0f - $%.0f" % (dec["predicted_rate"].min(), dec["predicted_rate"].max()))

smd = ((X_val.mean() - X_train.mean()) / X_train.std()).abs().sort_values(ascending=False)   # standardized mean shift per feature
print("\nLargest train->validation feature shifts (in std-devs):\n", smd.head(6).round(3))


# ## 11. Run the official scorer
# **Why:** `score.py` checks the two files (format, 12,000 ids, positive values, the 31 fixed December rows) and draws
# the December chart that goes in the report. Spotter computes the real accuracy afterwards.

# In[15]:


r = subprocess.run([sys.executable, "score.py", "--predictions", "validation_predictions.csv",
                    "--december-predictions", "data/december_chart_inputs.csv"], capture_output=True, text=True)
print(r.stdout, r.stderr)                                                 # should end with "Created chart: ..."
display(Image("scorer_results/candidate_december.png"))                   # show the chart


# ## Summary & honest limitations
# * **Split:** expanding-window, time-based; random split shown to be over-optimistic.
# * **Cleaning:** negative weights → `abs()`, missing weight/market_index → train-learned fills + flags, label outliers
#   (about 1.4%) dropped from *train only*; nothing dropped from validation.
# * **Model:** linear log-distance×equipment baseline + LightGBM on its residual (5-seed average).
# * **Limitations:** Nov–Dec are months with no training history, so any seasonal change in the market level cannot be
#   learned (month features were deliberately excluded and `market_index` did not transfer across time). Raw error is
#   dominated by noisy labels that no model can predict; the "clean" numbers show model quality without them.
