#!/usr/bin/env bash
# One-command setup for macOS / Linux:  bash setup_env.sh
set -euo pipefail

PY="${PYTHON:-python3}"                                   # use $PYTHON if set, else python3
"$PY" -c 'import sys; assert sys.version_info >= (3, 11), f"Python 3.11+ needed, found {sys.version.split()[0]}"'

echo ">> creating virtual environment in .venv"
"$PY" -m venv .venv                                       # isolated environment inside the project

echo ">> installing dependencies"
.venv/bin/python -m pip install --upgrade pip --quiet
.venv/bin/python -m pip install -r requirements.txt --quiet

echo ">> registering Jupyter kernel 'freight-rate'"
.venv/bin/python -m ipykernel install --user --name freight-rate --display-name "Python (freight-rate)" >/dev/null

echo ">> verifying imports"
.venv/bin/python -c "import pandas, numpy, matplotlib, sklearn, lightgbm; print('OK  pandas', pandas.__version__, '| lightgbm', lightgbm.__version__)"

cat <<'MSG'

Done. Next:
  source .venv/bin/activate
  MPLBACKEND=Agg python run_pipeline.py        # reproduces all outputs
  jupyter lab                                  # or open model.ipynb (kernel: Python (freight-rate))
MSG
