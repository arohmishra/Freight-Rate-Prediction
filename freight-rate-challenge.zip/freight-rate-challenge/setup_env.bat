@echo off
REM One-command setup for Windows:  setup_env.bat
python -c "import sys; assert sys.version_info >= (3, 11), 'Python 3.11+ needed'" || exit /b 1

echo ^>^> creating virtual environment in .venv
python -m venv .venv || exit /b 1

echo ^>^> installing dependencies
.venv\Scripts\python -m pip install --upgrade pip --quiet
.venv\Scripts\python -m pip install -r requirements.txt --quiet || exit /b 1

echo ^>^> registering Jupyter kernel
.venv\Scripts\python -m ipykernel install --user --name freight-rate --display-name "Python (freight-rate)"

.venv\Scripts\python -c "import pandas, numpy, matplotlib, sklearn, lightgbm; print('OK pandas', pandas.__version__, '| lightgbm', lightgbm.__version__)"

echo.
echo Done. Next:
echo   .venv\Scripts\activate
echo   set MPLBACKEND=Agg ^&^& python run_pipeline.py
echo   jupyter lab
