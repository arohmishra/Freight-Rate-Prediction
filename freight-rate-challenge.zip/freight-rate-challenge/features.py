"""Cleaning + feature engineering for the freight-rate task.

GOLDEN RULE: anything the code *learns* (medians, baseline line, city/lane effects)
is learned from TRAIN ONLY. Validation / holdout / December rows are only transformed.
That is what prevents data leakage.

Typical use
-----------
    fb      = FeatureBuilder()
    X_train = fb.fit_transform(train_df)                          # learns + builds train features
    X_val   = fb.transform(val_df)                                # applies what was learned
    X_dec   = fb.transform(dec_df, market_context=val_df)         # December chart rows
"""
from __future__ import annotations                      # lets us write modern type hints on older Pythons

import numpy as np                                      # fast numeric arrays / maths
import pandas as pd                                     # tables (DataFrames)
from pandas.tseries.holiday import USFederalHolidayCalendar   # list of US federal holidays
from sklearn.model_selection import KFold               # used for out-of-fold encodings

TARGET = "posted_rate"                                  # the column we are predicting
OUTLIER_LOW, OUTLIER_HIGH = 0.5, 2.0                    # keep rows whose rate/mile is 0.5x-2x of "typical"
EQUIPMENT = ["Dry Van", "Flatbed", "Reefer"]            # the 3 trailer types seen in the data


# --------------------------------------------------------------------------- #
# helper functions
# --------------------------------------------------------------------------- #
def haversine_miles(lat1, lon1, lat2, lon2):
    """Straight-line ('as the crow flies') distance in miles between two lat/lon points."""
    lat1, lon1, lat2, lon2 = map(np.radians, (lat1, lon1, lat2, lon2))   # degrees -> radians
    a = (np.sin((lat2 - lat1) / 2) ** 2
         + np.cos(lat1) * np.cos(lat2) * np.sin((lon2 - lon1) / 2) ** 2)  # haversine formula
    return 3958.8 * 2 * np.arcsin(np.sqrt(a))                            # 3958.8 = Earth radius in miles


def drop_label_outliers(train: pd.DataFrame, verbose: bool = True) -> pd.DataFrame:
    """TRAIN ONLY. Drop rows whose rate-per-mile is far from the norm for that equipment+month."""
    rpm = train[TARGET] / train["distance"]                              # rate per mile of every load
    month = pd.to_datetime(train["date"]).dt.to_period("M")              # calendar month of every load
    typical = rpm.groupby([train["equipment"], month]).transform("median")  # median rpm of its equipment+month
    ratio = rpm / typical                                                # 1.0 = perfectly typical
    keep = (ratio > OUTLIER_LOW) & (ratio < OUTLIER_HIGH)                # True for "believable" rows
    if verbose:
        print(f"[outliers] dropped {(~keep).sum()} of {len(train)} train rows ({(~keep).mean():.2%})")
    return train[keep].reset_index(drop=True)                            # return only believable rows


def _design(df: pd.DataFrame) -> np.ndarray:
    """Matrix for the tiny linear baseline:  log(rate) ~ log(distance), separately per equipment."""
    ld = np.log(df["distance"].to_numpy())                               # log of distance
    cols = [np.ones(len(df)), ld]                                        # intercept + slope for Dry Van
    for e in EQUIPMENT[1:]:                                              # for Flatbed and Reefer ...
        m = (df["equipment"] == e).to_numpy().astype(float)              # 1 if this load is that equipment
        cols += [m, m * ld]                                              # extra intercept + extra slope
    return np.column_stack(cols)                                         # stack into an (n_rows x 6) matrix


# --------------------------------------------------------------------------- #
# main class
# --------------------------------------------------------------------------- #
class FeatureBuilder:
    def __init__(self, smoothing: float = 40.0, n_folds: int = 5, seed: int = 42,
                 include_market: bool = False):
        # smoothing  : how strongly city/lane effects are shrunk toward 0 when a city has few loads
        # n_folds    : number of folds for out-of-fold encodings
        # seed       : random seed so results are reproducible
        # include_market : market_index features are OFF by default because, in our time-based
        #                  tests, they made predictions WORSE (see notebook section 6).
        self.smoothing, self.n_folds, self.seed = smoothing, n_folds, seed
        self.include_market = include_market

    # ---- learning step (train only) --------------------------------------- #
    def fit(self, train: pd.DataFrame) -> "FeatureBuilder":
        df = self._clean(train, fitting=True)                            # clean + remember fill values
        y = np.log(df[TARGET].to_numpy())                                # model log(rate): errors become %-errors
        self.beta_, *_ = np.linalg.lstsq(_design(df), y, rcond=None)     # least-squares fit of the baseline line
        resid = y - _design(df) @ self.beta_                             # what the baseline cannot explain
        self.enc_ = self._learn_encodings(df, resid)                     # average leftover per city / lane
        lane = df["pickup"] + ">" + df["delivery"]                       # a lane = "origin>destination"
        self.lane_dist_ = df.groupby(lane)["distance"].median()          # typical distance of each lane
        return self

    def fit_transform(self, train: pd.DataFrame) -> pd.DataFrame:
        """Learn from train, then build train features with OUT-OF-FOLD city/lane effects.

        Why out-of-fold? If a row's own rate were used to compute its city effect, the model
        would 'see the answer'. So each row's effect is computed from the OTHER folds only."""
        self.fit(train)                                                  # step 1: learn
        df = self._clean(train, fitting=False)                           # step 2: clean the same way
        y = np.log(df[TARGET].to_numpy())
        resid = y - _design(df) @ self.beta_
        oof = {k: np.zeros(len(df)) for k in ("pickup", "delivery", "lane")}   # empty result arrays
        splitter = KFold(self.n_folds, shuffle=True, random_state=self.seed)
        for tr_idx, te_idx in splitter.split(df):                        # for each fold ...
            enc = self._learn_encodings(df.iloc[tr_idx], resid[tr_idx])  # learn effects WITHOUT this fold
            for k, v in self._apply_encodings(df.iloc[te_idx], enc).items():
                oof[k][te_idx] = v                                       # store effects for this fold's rows
        return self._build(df, oof)                                      # step 3: assemble feature table

    # ---- apply step (validation / holdout / December) --------------------- #
    def transform(self, df: pd.DataFrame, market_context: pd.DataFrame | None = None) -> pd.DataFrame:
        """Build features for new rows. `market_context` supplies market columns when `df` has none
        (the December chart file has no quote_signal / market_index)."""
        d = df.copy()                                                    # never modify the caller's data
        if "market_index" not in d.columns or "quote_signal" not in d.columns:
            if market_context is None:
                raise ValueError("df has no market columns; pass market_context=validation_df")
            ctx = market_context.copy()
            ctx["market_index"] = pd.to_numeric(ctx["market_index"], errors="coerce")
            ctx["date"] = pd.to_datetime(ctx["date"])                    # make date types match on both sides
            d["date"] = pd.to_datetime(d["date"])
            day = ctx.groupby("date")[["market_index", "quote_signal"]].mean()   # per-date average (features only, no labels)
            d["market_index"] = d["date"].map(day["market_index"])       # look up each row's date
            d["quote_signal"] = d["date"].map(day["quote_signal"])
        d = self._add_coords(d)                                          # add lat/lon if the file lacks them
        d = self._clean(d, fitting=False)                                # same cleaning as train
        return self._build(d, self._apply_encodings(d, self.enc_))       # use effects learned on train

    # ---- internals --------------------------------------------------------- #
    def _clean(self, df: pd.DataFrame, fitting: bool) -> pd.DataFrame:
        d = df.copy()
        d["weight"] = d["weight"].abs()                                  # negative weights are sign errors -> make positive
        d["date"] = pd.to_datetime(d["date"])                            # text -> real dates
        d["weight_missing"] = d["weight"].isna().astype(int)             # flag BEFORE filling
        d["market_index_missing"] = d["market_index"].isna().astype(int)
        if fitting:                                                      # only on train: learn the fill values
            self.weight_med_ = float(d["weight"].median())
            self.mi_med_ = float(d["market_index"].median())
            both = pd.concat([                                           # city -> (lat, lon) lookup table
                d[["pickup", "pickup_lat", "pickup_lon"]].set_axis(["city", "lat", "lon"], axis=1),
                d[["delivery", "delivery_lat", "delivery_lon"]].set_axis(["city", "lat", "lon"], axis=1)])
            self.coords_ = both.groupby("city")[["lat", "lon"]].first()
        d["weight"] = d["weight"].fillna(self.weight_med_)               # missing weight -> train median
        mi_day = d.groupby("date")["market_index"].transform("median")   # median of other loads on the same date
        d["market_index"] = d["market_index"].fillna(mi_day).fillna(self.mi_med_)   # same-date, else train median
        return d

    def _add_coords(self, d: pd.DataFrame) -> pd.DataFrame:
        d = d.copy()
        for side in ("pickup", "delivery"):
            if f"{side}_lat" not in d.columns:                           # the December file has no coordinates
                d[f"{side}_lat"] = d[side].map(self.coords_["lat"])      # so look them up from train cities
                d[f"{side}_lon"] = d[side].map(self.coords_["lon"])
        return d

    def _learn_encodings(self, df: pd.DataFrame, resid: np.ndarray) -> dict:
        r = pd.Series(resid, index=df.index)                             # leftover error per row
        keys = {"pickup": df["pickup"], "delivery": df["delivery"],
                "lane": df["pickup"] + ">" + df["delivery"]}
        enc = {}
        for name, key in keys.items():
            g = r.groupby(key).agg(["sum", "count"])                     # total leftover and #loads per group
            enc[name] = g["sum"] / (g["count"] + self.smoothing)         # smoothed average (few loads -> near 0)
        return enc

    def _apply_encodings(self, df: pd.DataFrame, enc: dict) -> dict:
        keys = {"pickup": df["pickup"], "delivery": df["delivery"],
                "lane": df["pickup"] + ">" + df["delivery"]}
        # a city/lane never seen in train gets 0.0 = "no extra information, trust the baseline"
        return {k: keys[k].map(enc[k]).fillna(0.0).to_numpy() for k in keys}

    def _build(self, d: pd.DataFrame, enc: dict) -> pd.DataFrame:
        X = pd.DataFrame(index=d.index)                                  # the feature table we fill in

        # ---- distance features ---------------------------------------------
        hav = haversine_miles(d.pickup_lat, d.pickup_lon, d.delivery_lat, d.delivery_lon)
        lane_dist = (d["pickup"] + ">" + d["delivery"]).map(self.lane_dist_)   # typical distance of this lane
        lane_dist = lane_dist.fillna(d["distance"])                      # unseen lane -> trust the load's own distance
                                                                         # (a geography-based guess failed: some city pairs have
                                                                         #  near-identical coordinates but a 70-mile distance)
        X["distance"] = d["distance"]                                    # reported distance (noisy)
        X["log_distance"] = np.log(d["distance"])                        # rates grow ~proportionally -> log scale
        X["log_haversine"] = np.log(hav.clip(lower=1))                   # straight-line distance (not noisy)
        X["lane_distance"] = lane_dist                                   # de-noised distance
        X["distance_dev"] = d["distance"] / lane_dist - 1                # how far this load's distance is off the lane norm
        X["is_short"] = (d["distance"] < 250).astype(int)                # short hauls are priced differently

        # ---- load features ---------------------------------------------------
        X["weight_k"] = d["weight"] / 1000                               # weight in thousands of lb
        X["weight_missing"] = d["weight_missing"]                        # was it imputed?
        for e in EQUIPMENT:                                              # one-hot equipment (0/1 columns)
            X[f"eq_{e.replace(' ', '_')}"] = (d["equipment"] == e).astype(int)

        # ---- geography (coordinates are consistent per city -> region proxy) --
        for c in ("pickup_lat", "pickup_lon", "delivery_lat", "delivery_lon"):
            X[c] = d[c]
        X["dlat"] = d.delivery_lat - d.pickup_lat                        # north/south direction of the haul
        X["dlon"] = d.delivery_lon - d.pickup_lon                        # east/west direction of the haul

        # ---- calendar (month / day-of-year are deliberately NOT used: train has no Nov/Dec) ----
        dt = d["date"]
        X["dow"] = dt.dt.dayofweek                                       # 0=Mon ... 6=Sun
        X["is_weekend"] = (X["dow"] >= 5).astype(int)
        X["day_of_month"] = dt.dt.day
        X["days_to_month_end"] = dt.dt.days_in_month - dt.dt.day
        hol = USFederalHolidayCalendar().holidays(dt.min() - pd.Timedelta(days=5),
                                                  dt.max() + pd.Timedelta(days=5))
        near = pd.Series(False, index=d.index)
        for off in (-1, 0, 1):                                           # day before, day of, day after
            near |= (dt + pd.Timedelta(days=off)).isin(hol)
        X["near_holiday"] = near.astype(int)

        # ---- market --------------------------------------------------------------
        X["quote_signal"] = d["quote_signal"]                            # helped in every CV fold -> kept
        if self.include_market:                                          # market_index family: optional, off by default
            day = d.groupby("date")[["market_index", "quote_signal"]].mean()
            X["market_index"] = d["market_index"]
            X["market_index_missing"] = d["market_index_missing"]
            X["mi_day_mean"] = dt.map(day["market_index"])
            X["qs_day_mean"] = dt.map(day["quote_signal"])
            X["mi_roll7"] = dt.map(day["market_index"].rolling(7, min_periods=1).mean())
            X["mi_dev"] = d["market_index"] - X["mi_day_mean"]

        # ---- baseline + learned effects -----------------------------------------
        X["baseline_log_rate"] = _design(d) @ self.beta_                 # the simple line's prediction (log scale)
        X["pickup_effect"] = enc["pickup"]                               # origin-city premium/discount
        X["delivery_effect"] = enc["delivery"]                           # destination-city premium/discount
        X["lane_effect"] = enc["lane"]                                   # lane-specific premium/discount
        return X
